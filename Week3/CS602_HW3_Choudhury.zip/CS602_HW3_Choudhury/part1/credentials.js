module.exports = {

    host:     'cluster0.kwjingk.mongodb.net',
    username: 'cs602_user',
    password: 'cs602_secret',
    database: 'cs602db'
}