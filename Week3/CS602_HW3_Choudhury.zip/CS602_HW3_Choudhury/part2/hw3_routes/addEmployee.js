module.exports = 
		
		// Fill in the code
		function addEmployee(req,res,next){
			res.render('addEmployeeView',{title: 'Add an employee'});
		};
