module.exports = {
    host:     'cluster0.fmkd1yc.mongodb.net',
	username: 'MahimC',
	password: 'MahimCs602',
	database: 'CustomerOrder'
}


//mongodb+srv://MahimC:<password>@cluster0.zoutd27.mongodb.net/?retryWrites=true&w=majority

//mongodb+srv://MahimC:<password>@cluster0.fmkd1yc.mongodb.net/?retryWrites=true&w=majority