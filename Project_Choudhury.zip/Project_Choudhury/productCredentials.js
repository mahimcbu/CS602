module.exports = {
    host:     'cluster0.fmkd1yc.mongodb.net',
	username: 'MahimC',
	password: 'MahimCs602',
	database: 'GroceryMart'
}